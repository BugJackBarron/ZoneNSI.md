FILE=bob_is_here.txt
if [ -f "$FILE" ]; then
echo "Bob est là ! Mais ou se trouve Bill.txt ?"
touch ../../../../i/c/i/Bill.txt
else
echo "Bob n'est pas là ! Recommencez !"
fi
